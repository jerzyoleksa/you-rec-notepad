# Godot Celeste Movement Demo
## The rights of the assets for Celeste are EXOK's and are used here with permission.
![godot windows opt tools 64_Xn9AULQyVj](https://github.com/Eneskp3441/Godot-Celeste-Movement-Demo/assets/100702845/67b043cc-dec9-47fd-a766-650ac36e4cb1)
#### Available mechanics:
1. Movement
2. Jumping
3. Wall Jump
4. Wall Slide
5. Dash
6. Hair
### Sources:
- https://maddythorson.medium.com/celeste-forgiveness-31e4a40399f1
